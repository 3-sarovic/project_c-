﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lec3
{
    public partial class assignment2 : Form
    {
        public assignment2()
        {
            InitializeComponent();
        }
        private void traingforsender(object sender, EventArgs e)
        { if (sender is Button)
            {
                if (sender == butred)
                    button1.BackColor = Color.Red;
                else if (sender == butyellow)
                    button1.BackColor = Color.Yellow;
                else if (((Button)sender).Text == butgreen.Text)
                    button1.BackColor = Color.Green;
            }
            else if (sender is Label)
            { if (((Label)sender).Text == "جهاز 1")
                    button1.Text = label1.Text;
                else if (sender == label2)
                    button1.Text = label2.Text; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void butgreen_Click(object sender, EventArgs e)
        {
            //traingforsender(sender,e);
        }

        private void butred_Click(object sender, EventArgs e)
        {
            //traingforsender(sender,e);
        }

        private void butyellow_Click(object sender, EventArgs e)
        {
            //traingforsender(sender,e);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //traingforsender(sender,e);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //traingforsender(sender,e);
        }

        private void assignment2_Load(object sender, EventArgs e)
        {
            butgreen.Click += traingforsender;
            butred.Click += traingforsender;
            butyellow.Click += traingforsender;
            label1.Click += traingforsender;
            label2.Click += traingforsender;
        }
    }
}
