﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lec3
{
    public partial class assignment3_2 : Form
    {
        double x, y, z;
        string[] op = { "+", "-", "*", "/" };
        public assignment3_2()
        {
            InitializeComponent();
            comboBox1.Items.Add("+");
            comboBox1.Items.Add("-");
            comboBox1.Items.Add("*");
            comboBox1.Items.Add("/");
            //lilistBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            try
            { x = Convert.ToDouble(txtno1.Text); }
            catch (Exception)
            {
                MessageBox.Show("first number is invalid", "warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtno1.Text = "";
                txtno1.Focus();
                return;
            }
            try
            { y = Convert.ToDouble(txtno2.Text); }
            catch (Exception)
            {
                MessageBox.Show("second number is invalid", "warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtno2.Text = "";
                txtno2.Focus();
                return;
            }
            bool f = true;
            switch (comboBox1.SelectedIndex)
            {
                case 0: z = x + y; break;
                case 1: z = x - y; break;
                case 2: z = x * y; break;
                case 3:
                    if (y != 0)
                    {
                        z = x / y;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("we can not divided by zero");
                        f = false;
                        txtr.Text = null;
                        break;
                    }
            }
            if (f)
            {
                if (comboBox1.Text != "")
                    txtr.Text = z.ToString();
                else
                    txtr.Text = "";
            }
            
        }

        private void assignment3_2_Load(object sender, EventArgs e)
        {
            txtr.ReadOnly = true;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtno1.Text = txtno2.Text = txtr.Text = null;
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
