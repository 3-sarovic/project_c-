﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace lec3
{
    public partial class assignment1 : Form
    {
        public assignment1()
        {
            InitializeComponent();
        }
        private double performop(double n1,double n2,string op)
        {  switch(op)
            { case "+":
                  return n1+n2; 
              case "-":
                  return n1-n2; 
              case "*":
                    return n1*n2; 
              case "/":
                    return n2 !=0 ? n1/n2 : double.NaN; 
              default:
                    MessageBox.Show("the operation is error");
                    return double.NaN;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            double no1,no2,no3;
            string opration1 = textopration1.Text;
            string opration2 = textopration2.Text;
            string res1 = "";
            string res2 = "";
            if (double.TryParse(textnumber1.Text, out no1) &&
                double.TryParse(textnumber2.Text, out no2) &&
                double.TryParse(textnumber3.Text, out no3))
            {
                //res1 = performop(no1, no2, opration1).ToString();
                //if (res1 == "NaN")
                //{
                //    MessageBox.Show("the operation1 not correct");
                //    textopration1.Focus();
                //    return;

                //}
                if (opration2 == "*" || opration2 == "/")
                { res1 = performop(no2, no3, opration2).ToString();
                    res2 = performop(Convert.ToDouble(res1),no1,opration1).ToString();
                }
                else
                {
                    res1 = performop(no1, no2, opration1).ToString();
                    res2 = performop(Convert.ToDouble(res1), no3, opration2).ToString();
                }
               
                //if (res2 == "NaN")
                //{
                //    MessageBox.Show("the operation2 not correct");
                //    textopration2.Focus();
                //    return; 
                   
                //}
                textresult.Text = res2.ToString();
            }
            else
                MessageBox.Show("pleas enter correct numbers");


        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void textresult_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void assignment1_Load(object sender, EventArgs e)
        {

        }
    }
}
