﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lec3
{
    public partial class assignment3 : Form
    {   double x,y,z;

       

        string[] op = { "+", "-", "*", "/" };

        public assignment3()
        {
            InitializeComponent();
            listBox1.Items.Add("+");
            listBox1.Items.Add("-");
            listBox1.Items.Add("*");
            listBox1.Items.Add("/");
            //lilistBox1.SelectedIndex = 0;
        }

       

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            { x = Convert.ToDouble(txtno1.Text); }
            catch(Exception) 
            { MessageBox.Show( "first number is invalid", "warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtno1.Text = "";
                txtno1.Focus();
                return;
            }
            try
            { y = Convert.ToDouble(txtno2.Text); }
            catch (Exception)
            {
                MessageBox.Show( "second number is invalid", "warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtno2.Text = "";
                txtno2.Focus();
                return;
            }
            bool f = true;
            switch (listBox1.SelectedIndex)
            {
                case 0: z = x + y; break;
                case 1: z = x - y; break;
                case 2: z = x * y; break;
                case 3:
                    if (y != 0)
                    {
                        z = x / y;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("we can not divided by zero");
                        f = false;
                        txtr.Text = null;
                        break;
                    }
            }
            if(f)
                txtr.Text = z.ToString();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            txtno1.Text = txtno2.Text = txtr.Text = null;
        }
        private void assignment3_Load(object sender, EventArgs e)
        {
            txtr.ReadOnly = true;
            
        }
    }
}
